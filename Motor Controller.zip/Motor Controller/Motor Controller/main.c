/*
 * Motor Controller.c
 *
 * Created: 3/21/2019 9:19:32 PM
 * Author : Rony
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>


#define F_CPU 1000000ul;
volatile uint8_t adc_value;
void setup_timer(void);
void setup_ADC(void);
int main(void)
{
    DDRB |=(1<<PINB1);
	
	/* Replace with your application code */
	setup_timer();
	setup_ADC();
    while (1) 
    {
	}
}

void setup_timer(void)
{
	//Fast PWM, 1us, ICR1 top, clear on compare match only by OCR1A
	TCCR1A	|=(1<<COM1A1) |(1<<WGM11);
	TCCR1B  |=(1<<WGM12) |(1<<WGM13) |(1<<CS10);

	ICR1=1023;
	OCR1A =10;
	
}
void setup_ADC(void)
{
	ADMUX |=(1<<REFS0) ;//Right ADJUSTED, 5V REF
	ADCSRA|=(1<<ADPS1) |(1<<ADPS0)|(1<<ADIE) ;//prescaler 8=125khz
	ADCSRA|=(1<<ADEN);// interrupt enable
	sei(); //set external interrupt
	ADCSRA|=(1<<ADSC);//start conversion. after convertion completed ISR will be called
	
	
	
}

ISR(ADC_vect)
{
	uint8_t theLow=ADCL;
	uint16_t tenBitValue= (ADCH<<8)| theLow;
	
	
	if (tenBitValue<10)
	{
		OCR1A=10;
	}
	else if(tenBitValue >1015)
	{
		OCR1A=1015;
	}
	else
	{
		OCR1A=tenBitValue;
	}
	ADCSRA|=(1<<ADSC);// start conversion again.
}